//Global Variables
var monkey,monkeyimg;
var back, backimg;
var stone, stoneimg;
var stoneGroup;
var gameOver,gameOverimg;
var reset,resetimg
var banana,bananaimg
var count



function preload(){
  monkeyimg=loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
  
  backimg=loadAnimation("jungle.jpg")
  
  stoneimg=loadImage("stone.png")
  
  gameOverimg=loadImage("gameOver.png")
  
  resetimg=loadImage("restart.png")
  
  bananaimg=loadAnimation("banana.png")

}


function setup() {
  createCanvas(600,300);
   back=createSprite(300,150,20,30)
  back.addAnimation("background",backimg)
  back.scale=1.1
  back.velocityX=-5.5
  
  
  monkey=createSprite(100,230,20,30);
  monkey.addAnimation("monkey",monkeyimg);
  monkey.scale=0.2
  
  banana=createSprite(random(40,450),40,20,50)
  banana.addAnimation("banana",bananaimg)
  
 stoneGroup=createGroup()
  
 
}


function draw(){
 background(255);
   if(back.x<0){
    back.x=300 }
  
  if(frameCount%130===0){
    stone=createSprite(random(200,500),280,20,50)
    stone.addAnimation("stone",stoneimg);
    stone.velocityX=-5.5
    stone.scale=0.1
    stoneGroup.add(stone)
  }
  
  if(monkey.collide(stoneGroup)){
  reset();
  }
  count=frameCount%60===0
  text('score',500,100)
  drawSprites();
}

function reset(){
monkey.velocityX=0;
  back.velocityX=0
  stone.velocityX=0

gameOver=createSprite(250,245,20,30);
  gameOver.addAnimation("gameover",gameOverimg);
  gameOver.scale=0.8
  stone.remove(stoneGroup)
  var reset=createSprite(250,275,20,30)
  reset.addAnimation("reset",resetimg)
  reset.scale=0.6
  

}



